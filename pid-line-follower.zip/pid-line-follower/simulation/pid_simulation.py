"""
PID gain-tuning simulation for a line-following robot.

Models a simplified 2D kinematic robot following a generated track centerline,
using the same PID control law as the Arduino firmware (u = Kp*e + Ki*int(e) + Kd*de/dt),
so you can visualize step response / overshoot / settling and sweep gains before
flashing hardware.

Usage:
    python pid_simulation.py --kp 0.8 --ki 0.02 --kd 0.15 --track s_curve
    python pid_simulation.py --sweep   # grid-search Kp/Kd, report best by tracking error
"""
from __future__ import annotations

import argparse
import itertools

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


# ---------------- Track definitions ----------------
def track_straight(x: np.ndarray) -> np.ndarray:
    return np.zeros_like(x)


def track_s_curve(x: np.ndarray) -> np.ndarray:
    return 0.6 * np.sin(x / 3.0)


def track_sharp_turn(x: np.ndarray) -> np.ndarray:
    y = np.zeros_like(x)
    turn_start = len(x) // 2
    y[turn_start:] = 1.2 * (1 - np.exp(-(x[turn_start:] - x[turn_start]) / 2.0))
    return y


TRACKS = {
    "straight": track_straight,
    "s_curve": track_s_curve,
    "sharp_turn": track_sharp_turn,
}


# ---------------- Robot + PID simulation ----------------
def simulate(kp: float, ki: float, kd: float, track_name: str,
             n_steps: int = 600, dt: float = 0.02, sensor_noise_std: float = 0.02):
    """Simulate a robot with lateral position `y_robot` trying to track `y_line(x)`.

    Simplified model: the PID correction directly drives lateral velocity (a
    reasonable proxy for differential-drive steering at roughly-constant forward
    speed). Sensor noise is added to the position error to mimic real IR sensor
    quantization/jitter.
    """
    rng = np.random.default_rng(0)
    x = np.linspace(0, 20, n_steps)
    y_line = TRACKS[track_name](x)

    y_robot = np.zeros(n_steps)
    y_robot[0] = 0.0

    integral = 0.0
    prev_error = 0.0
    lateral_velocity = 0.0

    for i in range(1, n_steps):
        true_error = y_line[i - 1] - y_robot[i - 1]
        measured_error = true_error + rng.normal(0, sensor_noise_std)

        integral += measured_error * dt
        integral = np.clip(integral, -5, 5)
        derivative = (measured_error - prev_error) / dt
        correction = kp * measured_error + ki * integral + kd * derivative
        prev_error = measured_error

        # Robot lateral dynamics: correction drives lateral acceleration, damped.
        lateral_accel = correction - 0.5 * lateral_velocity
        lateral_velocity += lateral_accel * dt
        y_robot[i] = y_robot[i - 1] + lateral_velocity * dt

    tracking_error = y_line - y_robot
    return x, y_line, y_robot, tracking_error


def report_metrics(tracking_error: np.ndarray) -> dict:
    return {
        "MAE": float(np.mean(np.abs(tracking_error))),
        "max_abs_error": float(np.max(np.abs(tracking_error))),
        "rms_error": float(np.sqrt(np.mean(tracking_error ** 2))),
    }


def plot_result(x, y_line, y_robot, out_path: str, title: str):
    plt.figure(figsize=(9, 4))
    plt.plot(x, y_line, "k--", label="Track centerline")
    plt.plot(x, y_robot, label="Robot path")
    plt.xlabel("Forward distance")
    plt.ylabel("Lateral position")
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()
    print(f"Saved plot to {out_path}")


def sweep_gains(track_name: str):
    kp_values = [0.3, 0.5, 0.8, 1.2, 1.6]
    kd_values = [0.0, 0.1, 0.2, 0.3]
    ki = 0.02

    best = None
    for kp, kd in itertools.product(kp_values, kd_values):
        _, _, _, err = simulate(kp, ki, kd, track_name)
        metrics = report_metrics(err)
        if best is None or metrics["rms_error"] < best[1]["rms_error"]:
            best = ((kp, ki, kd), metrics)
        print(f"Kp={kp:<5} Ki={ki:<6} Kd={kd:<5}  RMS={metrics['rms_error']:.4f}  MaxErr={metrics['max_abs_error']:.4f}")

    print(f"\nBest gains: Kp={best[0][0]}, Ki={best[0][1]}, Kd={best[0][2]}  (RMS error={best[1]['rms_error']:.4f})")


def main():
    parser = argparse.ArgumentParser(description="PID line-follower simulation / tuning")
    parser.add_argument("--kp", type=float, default=0.8)
    parser.add_argument("--ki", type=float, default=0.02)
    parser.add_argument("--kd", type=float, default=0.15)
    parser.add_argument("--track", type=str, default="s_curve", choices=list(TRACKS.keys()))
    parser.add_argument("--sweep", action="store_true", help="Grid-search Kp/Kd and report the best by RMS error")
    parser.add_argument("--out", type=str, default="results/pid_tracking.png")
    args = parser.parse_args()

    if args.sweep:
        sweep_gains(args.track)
        return

    x, y_line, y_robot, err = simulate(args.kp, args.ki, args.kd, args.track)
    metrics = report_metrics(err)
    print(f"Track: {args.track}  Kp={args.kp} Ki={args.ki} Kd={args.kd}")
    print(f"MAE={metrics['MAE']:.4f}  RMS={metrics['rms_error']:.4f}  MaxAbsErr={metrics['max_abs_error']:.4f}")

    import os
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    plot_result(x, y_line, y_robot, args.out,
                title=f"PID tracking ({args.track}) — Kp={args.kp} Ki={args.ki} Kd={args.kd}")


if __name__ == "__main__":
    main()

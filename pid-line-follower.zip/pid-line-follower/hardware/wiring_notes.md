# Hardware: Wiring Notes & Bill of Materials

## Bill of materials (typical build)

| Component | Qty | Notes |
|---|---|---|
| Arduino Uno / Nano | 1 | Main controller |
| IR reflectance sensor array (e.g. 5-channel QTR-5) | 1 | Line sensing |
| Dual H-bridge motor driver (L298N or TB6612FNG) | 1 | Drives both DC motors |
| DC gear motors + wheels | 2 | Differential drive |
| Caster wheel | 1 | Third point of contact |
| Battery pack (7.4V Li-ion or 6x AA) | 1 | Power for motors + logic |
| Chassis | 1 | Mounts everything |
| Jumper wires | ~20 | |

## Pin mapping (matches `firmware/line_follower_pid.ino` defaults)

### IR sensor array → Arduino analog pins
| Sensor | Arduino pin |
|---|---|
| Sensor 1 (far left) | A0 |
| Sensor 2 | A1 |
| Sensor 3 (center) | A2 |
| Sensor 4 | A3 |
| Sensor 5 (far right) | A4 |

### Motor driver → Arduino digital pins
| Signal | Arduino pin | Driver pin (L298N naming) |
|---|---|---|
| Left motor direction 1 | D5 | IN1 |
| Left motor direction 2 | D6 | IN2 |
| Left motor PWM speed | D9 | ENA |
| Right motor direction 1 | D7 | IN3 |
| Right motor direction 2 | D8 | IN4 |
| Right motor PWM speed | D10 | ENB |

### Power
- Motor driver's motor-power input (`+12V`/`VMS`) connects to the battery pack directly
  (not through the Arduino's 5V regulator — DC motors draw too much current for that).
- Motor driver logic supply (`+5V`/`VCC`) can be taken from the Arduino 5V pin, or the
  driver's own onboard regulator if it has one — check your specific driver board.
- **Common ground is required**: battery ground, motor driver ground, and Arduino
  ground must all be tied together.

## Calibration tips

- Before running the PID loop, briefly sweep the sensor array over both the line and
  the background surface and print raw `analogRead()` values over serial to pick a
  good `LINE_THRESHOLD` for your specific surface/lighting.
- Mount the sensor array low and close to the surface (a few mm) for a crisper
  transition between "on line" / "off line" readings and less ambient-light noise.
- Keep motor power wiring short and, if using DC brushed motors, consider adding
  small ceramic capacitors across motor terminals to reduce electrical noise that can
  otherwise interfere with the analog sensor readings.

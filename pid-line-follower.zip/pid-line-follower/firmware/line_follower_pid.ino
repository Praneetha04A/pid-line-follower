/*
  PID-Controlled Autonomous Line-Following Robot
  ------------------------------------------------
  Reads an N-sensor IR reflectance array, computes a weighted-average line-position
  error, runs a PID control loop on that error, and differentially drives two DC
  motors via a standard dual H-bridge driver (e.g. L298N / TB6612FNG) to keep the
  robot centered on the line.

  Wiring: see ../hardware/wiring_notes.md

  Tip: tune Kp/Ki/Kd in simulation first (see ../simulation/pid_simulation.py),
  then fine-tune here against the real robot/track.
*/

// ---------------- Pin configuration ----------------
const uint8_t NUM_SENSORS = 5;
const uint8_t SENSOR_PINS[NUM_SENSORS] = {A0, A1, A2, A3, A4}; // left -> right

// Motor A (left) - via H-bridge
const uint8_t MOTOR_A_IN1 = 5;
const uint8_t MOTOR_A_IN2 = 6;
const uint8_t MOTOR_A_PWM = 9;   // ENA

// Motor B (right) - via H-bridge
const uint8_t MOTOR_B_IN1 = 7;
const uint8_t MOTOR_B_IN2 = 8;
const uint8_t MOTOR_B_PWM = 10;  // ENB

// ---------------- Robot / control parameters ----------------
const int BASE_SPEED = 150;       // 0-255 PWM, forward cruise speed
const int MAX_SPEED  = 255;

// PID gains — start with values from simulation, then tune live via Serial.
float Kp = 0.80;
float Ki = 0.02;
float Kd = 0.15;

// Sensor weights: position of each sensor relative to center, used for the
// weighted-average error calculation. Symmetric layout, outer sensors weighted
// more heavily since they indicate a larger deviation from center.
const float SENSOR_WEIGHTS[NUM_SENSORS] = {-2.0, -1.0, 0.0, 1.0, 2.0};

const unsigned long LOST_LINE_TIMEOUT_MS = 500; // stop motors if line lost this long
const int LINE_THRESHOLD = 500;                 // analog threshold: >threshold = "on line"
                                                 // (assumes dark line = higher analog reading;
                                                 //  invert comparison if your sensors read the opposite)

// ---------------- PID state ----------------
float integral = 0.0;
float previousError = 0.0;
unsigned long previousTimeMs = 0;
unsigned long lastLineSeenMs = 0;

void setup() {
  for (uint8_t i = 0; i < NUM_SENSORS; i++) {
    pinMode(SENSOR_PINS[i], INPUT);
  }
  pinMode(MOTOR_A_IN1, OUTPUT);
  pinMode(MOTOR_A_IN2, OUTPUT);
  pinMode(MOTOR_A_PWM, OUTPUT);
  pinMode(MOTOR_B_IN1, OUTPUT);
  pinMode(MOTOR_B_IN2, OUTPUT);
  pinMode(MOTOR_B_PWM, OUTPUT);

  Serial.begin(9600);
  previousTimeMs = millis();
  lastLineSeenMs = millis();
}

void loop() {
  unsigned long now = millis();
  float dt = (now - previousTimeMs) / 1000.0; // seconds
  if (dt <= 0) dt = 0.001; // guard against dt=0 on very fast loops

  float error;
  bool onLine = readLineError(error);

  if (onLine) {
    lastLineSeenMs = now;
  } else if (now - lastLineSeenMs > LOST_LINE_TIMEOUT_MS) {
    // Line lost for too long -> stop rather than drive blind.
    stopMotors();
    Serial.println("Line lost — stopped.");
    previousTimeMs = now;
    return;
  } else {
    // Brief gap: keep using last known error to coast through momentarily.
    error = previousError;
  }

  // ---- PID computation ----
  integral += error * dt;
  integral = constrain(integral, -100, 100); // anti-windup clamp
  float derivative = (error - previousError) / dt;

  float correction = Kp * error + Ki * integral + Kd * derivative;

  previousError = error;
  previousTimeMs = now;

  // ---- Differential drive ----
  int leftSpeed  = constrain(BASE_SPEED - correction, -MAX_SPEED, MAX_SPEED);
  int rightSpeed = constrain(BASE_SPEED + correction, -MAX_SPEED, MAX_SPEED);

  setMotor(MOTOR_A_IN1, MOTOR_A_IN2, MOTOR_A_PWM, leftSpeed);
  setMotor(MOTOR_B_IN1, MOTOR_B_IN2, MOTOR_B_PWM, rightSpeed);

  Serial.print("err="); Serial.print(error);
  Serial.print("  corr="); Serial.print(correction);
  Serial.print("  L="); Serial.print(leftSpeed);
  Serial.print("  R="); Serial.println(rightSpeed);
}

// Reads sensor array, returns weighted-average error in `error` (out param).
// Returns true if at least one sensor currently detects the line.
bool readLineError(float &error) {
  float weightedSum = 0.0;
  float totalWeight = 0.0;
  bool anyOnLine = false;

  for (uint8_t i = 0; i < NUM_SENSORS; i++) {
    int reading = analogRead(SENSOR_PINS[i]);
    if (reading > LINE_THRESHOLD) {
      anyOnLine = true;
      weightedSum += SENSOR_WEIGHTS[i] * reading;
      totalWeight += reading;
    }
  }

  if (!anyOnLine || totalWeight == 0) {
    error = previousError; // hold last error; caller decides whether to trust it
    return false;
  }

  error = weightedSum / totalWeight;
  return true;
}

// Drives a single motor given an H-bridge (IN1/IN2/PWM) and a signed speed (-255..255).
void setMotor(uint8_t in1, uint8_t in2, uint8_t pwmPin, int speed) {
  bool forward = speed >= 0;
  speed = constrain(abs(speed), 0, 255);

  digitalWrite(in1, forward ? HIGH : LOW);
  digitalWrite(in2, forward ? LOW : HIGH);
  analogWrite(pwmPin, speed);
}

void stopMotors() {
  analogWrite(MOTOR_A_PWM, 0);
  analogWrite(MOTOR_B_PWM, 0);
}

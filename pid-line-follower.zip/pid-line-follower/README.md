# PID-Controlled Autonomous Mobile Line-Following Robot

A real-time autonomous line-following robot built on Arduino, using a dynamically-tuned
Proportional-Integral-Derivative (PID) control loop for precise trajectory tracking,
reflectance-sensor-array path sensing, and closed-loop motor stabilization.

This repo contains:

1. **`firmware/`** — the Arduino sketch (`.ino`) that runs on the robot: IR reflectance
   sensor array reading, weighted-average line-position estimation, PID control loop,
   and differential motor-speed output (with a basic lost-line / obstacle-safety stop).
2. **`simulation/`** — a Python PID simulation/tuning tool that models a simplified
   line-following robot on an arbitrary track so you can visualize step response,
   overshoot, and settling behavior, and sweep PID gains *before* touching hardware.
3. **`hardware/`** — wiring notes and a bill of materials for the physical build
   (IR sensor array, dual DC motors + driver, Arduino Uno/Nano).

## Repository structure

```
pid-line-follower/
├── firmware/
│   └── line_follower_pid.ino     # Arduino firmware
├── simulation/
│   ├── pid_simulation.py         # Python simulation + gain-tuning sweep
│   └── requirements.txt
├── hardware/
│   └── wiring_notes.md           # sensor/motor wiring + BOM
├── LICENSE
└── README.md
```

## How the control loop works

1. **Sensing** — An array of N IR reflectance sensors reads the surface under the
   robot. Each sensor returns high/low (or analog) reflectance depending on whether
   it's over the dark line or the light background.
2. **Error estimation** — A weighted average across the sensor array gives a single
   scalar `position error`, where 0 means the line is centered, negative means the
   line has drifted left, positive means it's drifted right.
3. **PID control** — 
   - **P** (Proportional) reacts to the current error — how far off-center the robot is right now.
   - **I** (Integral) accumulates past error — corrects small persistent drift (e.g. a
     wheel mismatch) that P alone can't remove.
   - **D** (Derivative) reacts to the rate of change of error — dampens oscillation and
     prevents overshoot on sharp turns.
   - The combined correction `u = Kp*e + Ki*∫e + Kd*(de/dt)` is added/subtracted from a
     base motor speed to differentially drive the left/right wheels.
4. **Actuation** — Motor driver (e.g. L298N/TB6612) receives the corrected left/right
   PWM speeds, steering the robot back toward the line.

## Tuning the PID gains (do this in simulation first)

```bash
cd simulation
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python pid_simulation.py --kp 0.8 --ki 0.02 --kd 0.15 --track s_curve
```

This plots the simulated robot's trajectory against the track centerline and reports
overshoot / settling time, so you can iterate on `Kp`, `Ki`, `Kd` before flashing
firmware. Once you have a good starting point, transfer those gains into
`firmware/line_follower_pid.ino` and fine-tune on the real robot (tracks tend to need
somewhat higher gains than the idealized simulation due to real sensor noise and
motor deadband).

## Flashing the firmware

1. Open `firmware/line_follower_pid.ino` in the Arduino IDE (or `arduino-cli`).
2. Adjust `NUM_SENSORS`, sensor pins, and motor pins in the `// ---- Pin configuration ----`
   block to match your wiring (see `hardware/wiring_notes.md`).
3. Set starting `Kp`, `Ki`, `Kd` (from the simulation step above).
4. Upload, place the robot on the line, and fine-tune gains via the serial monitor
   (the sketch prints live error/PID terms at `Serial.begin(9600)`).

## Safety behavior

If all sensors report "off-line" for longer than `LOST_LINE_TIMEOUT_MS`, the firmware
stops both motors rather than driving blind — adjust this behavior in `loop()` if your
track has intentional line gaps.

## License

MIT — see `LICENSE`.
